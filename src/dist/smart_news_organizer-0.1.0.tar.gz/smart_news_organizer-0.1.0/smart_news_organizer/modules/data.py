#!/usr/bin/python3


SYSTEM_DATA = {
    "api_key"  : "",
    "usage"    : "https://deepinfra.com/dash/usage",
    "base_url" : "https://api.deepinfra.com/v1/openai",
    "model"    : "meta-llama/Meta-Llama-3.1-70B-Instruct"
}
